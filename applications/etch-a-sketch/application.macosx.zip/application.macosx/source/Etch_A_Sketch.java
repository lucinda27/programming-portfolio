import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Etch_A_Sketch extends PApplet {

int x, y;

public void setup() {
  
  frameRate(10);
  // Set start coordinates
  x = 0;
  y = 0;
}

public void draw() {
  fill(0);
  if (keyPressed) {
    if (key == 'd' || key == 'D') {
      moveRight(5);
    } else if (key == 'a' || key == 'A') {
      moveLeft(5);
    } else if (key == 'w' || key == 'W') {
      moveUp(5);
    } else if (key == 's' || key == 'S') {
      moveDown(5);
    }
  }
  //drawName();
  //noLoop();
}

public void mouseClicked() {
  saveFrame("image-######.png");
}

public void keyPressed() {
  if (key == CODED) {
    if (keyCode == RIGHT) {
      moveRight(5);
    } else if (keyCode == LEFT) {
      moveLeft(5);
    } else if (keyCode == UP) {
      moveUp(5);
    } else if (keyCode == DOWN) {
      moveDown(5);
    }
  }
}

// Algorithm for your first name
public void drawName() {
  moveRight(25);
  moveDown(100);
  moveRight(50);
  movePPdiagonal(30);
  moveDown(30); 
  moveRight(30);
  moveUp(30);
  moveDown(30);
  movePPdiagonal (30); 
  moveRight(30);
  moveLeft(30);
  moveDown(30);
  moveRight(30);
  movePPdiagonal(30);
  moveDown(30);
  moveRight(30);
  moveUp(30);
  moveDown(30);
  moveNNdiagonal(60);
}


// Method to draw right lines
public void moveRight(int rep) {
  for (int i = 0; i<rep; i = i + 1) {
    point(x+i, y);
  }
  x=x+rep;
}

// Method to draw left lines
public void moveLeft(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y);
  }
  x=x-rep;
}

// Method to draw up lines
public void moveUp(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x, y-i);
  }
  y=y-rep;
}

// Method to draw down lines
public void moveDown(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x, y+i);
  }
  y=y+rep;
}

// Method to draw positive-positive diagonal lines
public void movePPdiagonal(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y-i);
  }
  x=x+rep;
  y=y-rep;
}

// Method to draw negative-negative diagonal lines
public void moveNNdiagonal(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y+i);
  }
  x=x-rep; 
  y=y+rep;
}

// Method to draw positive-negative diagonal lines
public void movePNdiagonal(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y+i);
  }
  x=x+rep;
  y=y+rep;
}

// Method to draw negative-positive diagonal lines
public void moveNPdiagonal(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y-i);
  }
  x=x-rep;
  y=y-rep;
}
  public void settings() {  size(400, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Etch_A_Sketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
